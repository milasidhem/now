package com.example.myapplication.model;
import java.util.Date;

public class Announce {

    //proprietes
    private String image_url;
    private Date date;
    private String comment;

    public Announce(String image_url, Date date, String comment) {
        this.image_url = image_url;
        this.date = date;
        this.comment = comment;
    }

    public String getImage_url() {
        return image_url;
    }


    public Date getDate() {
        return date;
    }


    public String getComment() {
        return comment;
    }

}
