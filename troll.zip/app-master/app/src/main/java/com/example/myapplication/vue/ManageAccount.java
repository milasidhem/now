package com.example.myapplication.vue;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class ManageAccount extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    Controle controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_account);
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
    }
    public void Manage(View v){
        switch (v.getId()){
            case R.id.chngpsw :
                Intent swwitchPass = new Intent(this,ChangePassword.class);
                startActivity(swwitchPass);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                finish();
                break;
            case R.id.chngphn :
                Intent swwitchPho = new Intent(this,ChangePhoneNumber.class);
                startActivity(swwitchPho);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                finish();
                break;
            case R.id.save :
                Intent swwitchSav = new Intent(this,HomePage.class);
                startActivity(swwitchSav);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                finish();
                break;
            case R.id.delete :
                Intent swwitchDel = new Intent(this,Delete.class);
                startActivity(swwitchDel);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                finish();
                break;
            case R.id.logout :
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("key", 0);
                editor.apply();
                Intent swwitchLogout = new Intent(this,Login.class);
                startActivity(swwitchLogout);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                finish();
                break;
            case R.id.contact :
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto","amadinatec@gmail.com ", null));
                intent.putExtra(Intent.EXTRA_SUBJECT, "");
                intent.putExtra(Intent.EXTRA_TEXT, "");
                startActivity(Intent.createChooser(intent, "Choose an Email client :"));
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                finish();
                break;

        }
    }

    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        finish();
    }

}
