package com.example.myapplication.vue;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Announce;
import com.example.myapplication.model.Report;
import com.example.testprojet.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Collections;

public class HomePage extends AppCompatActivity {

    private BottomNavigationView navigation;
    private Controle controle;
    SharedPreferences sharedpreferences;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        this.controle = Controle.getInstance(this);
        sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedpreferences.getString("username", null);
        Toast toast = Toast.makeText(this, "hello  "+username, Toast.LENGTH_LONG);
        View toastView = toast.getView(); // This'll return the default View of the Toast.

        /* And now you can get the TextView of the default View of the Toast. */
        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
        toastMessage.setTextSize(15);
        toastMessage.setTextColor(Color.GRAY);
        toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_mine, 0, 0, 0);
        toastMessage.setGravity(Gravity.CENTER);
        toastMessage.setCompoundDrawablePadding(10);
        toastView.setBackgroundColor(Color.WHITE);
        toast.setGravity(Gravity.TOP , 0, 0);
        toast.show();
        controle.USER = username;
        controle.mine(controle.USER);
        controle.all();
        controle.announce();
        creerListe();
        navigation = findViewById(R.id.bottom_navigation);
        navigation.setOnNavigationItemSelectedListener(navi);
       //int reqCode = 1;
        //Intent intent = new Intent(this, WriteReport.class);
        //showNotification(this, "test", "sup nigga", intent, reqCode);
    }

    @Override
    protected void onResume(){
        super.onResume();
        //Toast.makeText(this,"Welcome "+username,Toast.LENGTH_LONG).show();
        controle.mine(username);
    }

    /**
     * créer la liste adapter
     */
    private void creerListe(){
        ArrayList<Announce> mesAnnounces = controle.getMesAnnounces();
        //Collections.sort(mesAnnounces, Collections.<Announce>reverseOrder());
        if(mesAnnounces != null){
            LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
                RecyclerView lsAnc = findViewById(R.id.list_announce);
            lsAnc.setLayoutManager(layoutManager);
            AnnounceListAdapter adapter = new AnnounceListAdapter(mesAnnounces,this);
            lsAnc.setAdapter(adapter);
        }
    }


    /**
     *
     * @param context
     * @param title  --> title to show
     * @param message --> details to show
     * @param intent --> What should happen on clicking the notification
     * @param reqCode --> unique code for the notification
     */
    public void showNotification(Context context, String title, String message, Intent intent, int reqCode) {
        //SharedPreferenceManager sharedPreferenceManager = SharedPreferenceManager.getInstance(context);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, reqCode, intent, PendingIntent.FLAG_ONE_SHOT);
        String CHANNEL_ID = "channel_name";// The id of the channel.
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_mine)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel Name";// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            notificationManager.createNotificationChannel(mChannel);
        }
        notificationManager.notify(reqCode, notificationBuilder.build()); // 0 is the request code, it should be unique id

        Log.d("showNotification", "showNotification: " + reqCode);
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navi = new
            BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()){
                        case R.id.write :
                            Intent intentW = new Intent(HomePage.this, WriteReport.class);
                            //intentW.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentW);
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                            break;
                        case R.id.search :
                            if(controle.limit==0){
                                Toast.makeText(HomePage.this,"no reports to show",Toast.LENGTH_LONG).show();
                            }
                            else {
                                Intent intentS = new Intent(HomePage.this, MapsActivity.class);
                                startActivity(intentS);
                                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                            }
                            break;
                        case R.id.list:
                            Intent intentL = new Intent(HomePage.this, ListReports.class);
                            //intentL.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentL);
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                            break;
                        case R.id.manage :
                            Intent intentM = new Intent(HomePage.this, ManageAccount.class);
                            //intentM.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentM);
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                            break;
                    }
                    return false;
                }
            };
    boolean dbl = false;

    @Override
    public void onBackPressed() {
        if (dbl) {
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
            return;
        }

        this.dbl = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                dbl=false;
            }
        }, 2000);
    }

}
