package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Report;
import com.example.testprojet.R;

import java.util.ArrayList;
import java.util.Collections;

public class ListReports extends AppCompatActivity {

    private Controle controle;
    private SwipeRefreshLayout swipeRefreshLayout;
    ListView ls;
    public Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_reports);
        this.controle = Controle.getInstance(this);
        this.controle.mine(controle.USER);
        controle.all();
        creerListe();
        context = this;
        swipeRefreshLayout = findViewById(R.id.swiperefresh);
        ls = findViewById(R.id.reportlist);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);
                ls.invalidateViews();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }
                },500);
            }
        });
    }

    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        finish();
    }
    /**
     * créer la liste adapter
     */
    private void creerListe(){
        ArrayList<Report> mesRapports = controle.getMesRapports();
        Collections.sort(mesRapports, Collections.<Report>reverseOrder());
        if(mesRapports != null){
            ListView lsRep = findViewById(R.id.reportlist);
            ReportListAdapter adapter = new ReportListAdapter(this,mesRapports,controle.USER);
            lsRep.setAdapter(adapter);
        }
    }
    public void affichReport(Report report){
        controle.setReport(report);
        Intent intent = new Intent(this, ViewReport.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
        finish();
    }
}
