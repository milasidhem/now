package com.example.myapplication.model;


import com.example.myapplication.outils.MesOutils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Report implements Comparable{

    //proprietes
    private String username;
    private String title;
    private String description;
    private double locx;
    private double locy;
    private Integer type;
    private String image;
    private Integer etat;
    private Date date1;
    private Date date2;
    private Date date3;
    private String comment;
    private String imagecomment;

    public Report(String username,String title, String description, double locx, double locy,
                  Integer type, String image, Integer etat,Date date1,Date date2,Date date3, String comment, String imagecomment) {
        this.username = username;
        this.title = title;
        this.description = description;
        this.locx = locx;
        this.locy = locy;
        this.type = type;
        this.image = image;
        this.etat = etat;
        this.date1 = date1;
        this.date2 = date2;
        this.date3 = date3;
        this.comment = comment;
        this.imagecomment = imagecomment;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public double getLocx() {
        return locx;
    }

    public double getLocy() {
        return locy;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getType() {
        return type;
    }

    public String getImage() {
        return image;
    }

    public Integer getEtat() {
        return etat;
    }

    public Date getDate1() {
        return date1;
    }

    public Date getDate2() {
        return date2;
    }

    public Date getDate3() {
        return date3;
    }

    public String getComment() {
        return comment;
    }

    public String getCommentImage() {
        return imagecomment;
    }



    /**
     * convertion d'un report au format JSONArray
     * @return
     */
    public JSONArray convertToJSONArray(){
        List laList = new ArrayList();
        laList.add(username); //0
        laList.add(title); //1
        laList.add(description); //2
        laList.add(locx); //3
        laList.add(locy); //4
        laList.add(type); //5
        laList.add(image); //6
        laList.add(MesOutils.convertDateToString(date1)); //7
        return new JSONArray(laList);
    }

    @Override
    public int compareTo(Object o) {
        return date1.compareTo(((Report)o).getDate1());
    }
}
